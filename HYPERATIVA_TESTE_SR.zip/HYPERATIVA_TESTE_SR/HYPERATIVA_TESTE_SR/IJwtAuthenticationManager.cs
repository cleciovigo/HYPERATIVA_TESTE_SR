﻿namespace HYPERATIVA_TESTE_SR
{
    public interface IJwtAuthenticationManager
    {
        string Authenticate(string username, string password);
    }
}
