﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using HYPERATIVA_TESTE_SR.Models;
using HYPERATIVA_TESTE_SR.Repositorios.Interfaces;
using System.Runtime.CompilerServices;
using Microsoft.AspNetCore.DataProtection;

namespace HYPERATIVA_TESTE_SR.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AcessoController : ControllerBase
    {
        private readonly JwtAuthenticationManager jwtAuthenticationManager;
        private readonly IUsuariuoRepositorio usuariuoRepositorio;
        private readonly IDataProtector dataProtector;

        public AcessoController(JwtAuthenticationManager jwtAuthenticationManager, IUsuariuoRepositorio _usuariuoRepositorio, IDataProtectionProvider provider)
        {
            this.jwtAuthenticationManager = jwtAuthenticationManager;
            this.usuariuoRepositorio = _usuariuoRepositorio;
            //this.dataProtector = provider.CreateProtector("Autorizacao");
        }
        [AllowAnonymous]
        [HttpPost("Autorizacao")]
        public async Task<IActionResult> autorizacao(string login, string senha)
        {
            UsuarioModel usuario = await usuariuoRepositorio.BuscarUsuario(login, senha);
            if (usuario == null)
            {
                return Unauthorized();
            }
            var token = jwtAuthenticationManager.Authenticate(login, senha);
            if (token == null)
            {
                return Unauthorized();
            }
            return Ok(token);
        }
       
    }
}

