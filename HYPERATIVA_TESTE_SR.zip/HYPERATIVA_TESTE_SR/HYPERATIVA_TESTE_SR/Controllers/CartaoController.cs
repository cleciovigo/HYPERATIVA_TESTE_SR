﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.DataProtection;
using HYPERATIVA_TESTE_SR.Models;
using HYPERATIVA_TESTE_SR.Repositorios.Interfaces;
using HYPERATIVA_TESTE_SR.Repositorios;
using System.Reflection.PortableExecutable;
using System.ComponentModel.Design;

namespace HYPERATIVA_TESTE_SR.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class CartaoController : ControllerBase
    {

        private readonly ICartaoRepositorio cartaoRepositorio;
        public CartaoController(ICartaoRepositorio _cartaoRepositorio)
        {
            cartaoRepositorio = _cartaoRepositorio;
        }

        [Authorize]
        [HttpGet("GetCartao")]
        public async Task<IActionResult> getCartao(string numeroCartao)
        {
            try
            {
                CartaoModel cartao = await cartaoRepositorio.BuscarCartao(numeroCartao);

                if (cartao != null)
                {
                    return Ok(cartao.CARTAO_ID);
                }
                else
                {
                    return Ok("Cartão não encontrado");
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [Authorize]
        [HttpPost("SetCartao")]
        public async Task<IActionResult> setCartao(string numeroCartao)
        {
            try
            {
                CartaoModel cartao = new CartaoModel();
                cartao.CARTAO_NUMERO = numeroCartao;
                await cartaoRepositorio.Adicionar(cartao);
                return Ok(cartao.CARTAO_ID);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }

        [Authorize]
        [HttpPost("SetCartaoEmLote")]
        public async Task<IActionResult> setCartaoEmLote(IFormFile arquivo)
        {
            if (arquivo == null)
            {
                return BadRequest("Arquivos não encontrados");
            }
            string mensagem = string.Empty;
            if (arquivo.Length > 0)
            {
                using (var stream = new MemoryStream())
                {
                    arquivo.CopyTo(stream);

                    string linha;


                    using (StreamReader sr = new StreamReader(stream))
                    {
                        sr.BaseStream.Position = 0;
                        string dados;
                        int contador = 1;
                        while ((dados = sr.ReadLine()) != null)
                        {
                            linha = dados;
                            if (contador == 1)
                            {
                                contador++;
                                continue;
                            }
                            if (linha.StartsWith("C"))
                            {
                                CartaoModel cartao = new CartaoModel();
                                linha = linha.PadRight(50, ' ');
                                string linhaLote = linha.Substring(1, 6).Trim();


                                cartao.CARTAO_NUMERO = linha.Substring(7, 18).Trim();
                                try
                                {

                                    CartaoModel c = await cartaoRepositorio.BuscarCartao(cartao.CARTAO_NUMERO);
                                    if (c == null)
                                    {
                                        await cartaoRepositorio.Adicionar(cartao);
                                    }
                                    else
                                    {
                                        if (mensagem.Length == 0)
                                        {
                                            mensagem = $"Não foi importada a linha do lote: {linhaLote}, ";
                                        }
                                        else
                                        {
                                            mensagem += $"{linhaLote}, ";
                                        }
                                    }

                                }
                                catch
                                {
                                    if (mensagem.Length == 0)
                                    {
                                        mensagem = $"Não foi importada a linha do lote: {linhaLote}, ";
                                    }
                                    else
                                    {
                                        mensagem += $"{linhaLote}, ";
                                    }

                                }

                            }

                        }
                    }
                }
            }

            if (mensagem.Length > 0)
            {
                mensagem = mensagem.Substring(0, mensagem.Length - 2);
            }
            return Ok(mensagem);

        }




    }
}
