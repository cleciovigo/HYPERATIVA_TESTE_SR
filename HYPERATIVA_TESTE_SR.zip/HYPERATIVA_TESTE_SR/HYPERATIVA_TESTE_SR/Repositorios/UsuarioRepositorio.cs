﻿using HYPERATIVA_TESTE_SR.Data;
using HYPERATIVA_TESTE_SR.Models;
using HYPERATIVA_TESTE_SR.Repositorios.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Runtime.CompilerServices;

namespace HYPERATIVA_TESTE_SR.Repositorios
{
    public class UsuarioRepositorio : IUsuariuoRepositorio
    {
        private readonly HYPERATIVA_TESTE_SR_DBContext _dbContext;
        public UsuarioRepositorio(HYPERATIVA_TESTE_SR_DBContext _HYPERATIVA_TESTE_SR_DBContext)
        {
            _dbContext = _HYPERATIVA_TESTE_SR_DBContext;
        }
        public async Task<UsuarioModel> BuscarUsuario(string login, string senha)
        {
            return await _dbContext.Usuarios.FirstOrDefaultAsync(x => x.USUARIO_LOGIN == login && x.USUARIO_SENHA == senha);
        }
    }
}
