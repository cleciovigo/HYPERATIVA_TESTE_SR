﻿using HYPERATIVA_TESTE_SR.Data;
using HYPERATIVA_TESTE_SR.Models;
using HYPERATIVA_TESTE_SR.Repositorios.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace HYPERATIVA_TESTE_SR.Repositorios
{
    public class CartaoRepositorio : ICartaoRepositorio
    {
        private readonly HYPERATIVA_TESTE_SR_DBContext _dbContext;
        public CartaoRepositorio(HYPERATIVA_TESTE_SR_DBContext _HYPERATIVA_TESTE_SR_DBContext)
        {
            _dbContext = _HYPERATIVA_TESTE_SR_DBContext;
        }
        public async Task<CartaoModel> BuscarCartao(string numero)
        {
            return await _dbContext.Cartao.FirstOrDefaultAsync(x => x.CARTAO_NUMERO == numero);
        }

        public async Task<CartaoModel> Adicionar(CartaoModel cartao)
        {
            _dbContext.Cartao.Add(cartao);
            _dbContext.SaveChanges();
            return cartao;
        }


    }
}
