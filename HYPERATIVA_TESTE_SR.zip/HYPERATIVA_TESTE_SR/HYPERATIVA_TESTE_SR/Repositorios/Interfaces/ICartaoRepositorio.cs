﻿using HYPERATIVA_TESTE_SR.Models;

namespace HYPERATIVA_TESTE_SR.Repositorios.Interfaces
{
    public interface ICartaoRepositorio
    {
        Task<CartaoModel> BuscarCartao(string numero);

       Task<CartaoModel> Adicionar(CartaoModel cartao);
    }
}
