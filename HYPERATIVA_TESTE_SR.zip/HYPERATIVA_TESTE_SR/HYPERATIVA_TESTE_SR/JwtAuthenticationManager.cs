﻿using System.IdentityModel.Tokens.Jwt;
using System.Text;
using Microsoft.IdentityModel.Tokens;
using System.Security.Claims;
using HYPERATIVA_TESTE_SR.Repositorios;
using HYPERATIVA_TESTE_SR.Models;
using HYPERATIVA_TESTE_SR.Repositorios.Interfaces;

namespace HYPERATIVA_TESTE_SR
{
    public class JwtAuthenticationManager
    {
        private readonly IUsuariuoRepositorio _UsuarioRepositorio;
        private readonly string key;
        public JwtAuthenticationManager(string key)
        {
            this.key = key;        
        }
      

        public string Authenticate(string username, string password)
        {                 
                    

          
            JwtSecurityTokenHandler tokenHandler = new JwtSecurityTokenHandler();
            var tokenKey = Encoding.ASCII.GetBytes(key);
            SecurityTokenDescriptor tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new Claim[]
                {
                    new Claim(ClaimTypes.Name, username)
                }),
                //set duration of token here
                Expires = DateTime.UtcNow.AddHours(1),
                SigningCredentials = new SigningCredentials(
                    new SymmetricSecurityKey(tokenKey),
                    SecurityAlgorithms.HmacSha256Signature)
            };
            var token = tokenHandler.CreateToken(tokenDescriptor);

            return tokenHandler.WriteToken(token);
        }
    }
}
