﻿namespace HYPERATIVA_TESTE_SR.Models
{
    public class UsuarioModel
    {
        public int USUARIO_ID { get; set; }     
        public string USUARIO_LOGIN { get; set; }
        public string USUARIO_SENHA { get; set; }
        public bool USUARIO_ATIVO { get; set; }



    }
}
