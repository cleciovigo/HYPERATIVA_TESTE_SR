﻿namespace HYPERATIVA_TESTE_SR.Models
{
    public class CartaoModel
    {
        public int CARTAO_ID { get; set; }

        public string CARTAO_NUMERO { get; set; }
    }
}
