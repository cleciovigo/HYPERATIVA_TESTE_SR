﻿using HYPERATIVA_TESTE_SR.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HYPERATIVA_TESTE_SR.Data.Map
{
    public class UsuarioMap : IEntityTypeConfiguration<UsuarioModel>
    {
        public void Configure(EntityTypeBuilder<UsuarioModel> builder)
        {
            builder.HasKey(x=> x.USUARIO_ID);
            builder.Property(x=> x.USUARIO_LOGIN).IsRequired().HasMaxLength(50);
            builder.Property(x=> x.USUARIO_SENHA).IsRequired().HasMaxLength(1000);
            builder.Property(x=> x.USUARIO_ATIVO).IsRequired();
        }
    }
}
