﻿using HYPERATIVA_TESTE_SR.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace HYPERATIVA_TESTE_SR.Data.Map
{
    public class CartaoMap : IEntityTypeConfiguration<CartaoModel>
    {
        public void Configure(EntityTypeBuilder<CartaoModel> builder)
        {
            builder.HasKey(x => x.CARTAO_ID);
            builder.Property(x => x.CARTAO_NUMERO).IsRequired().HasMaxLength(50);
        }
    }
}
