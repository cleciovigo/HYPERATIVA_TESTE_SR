﻿using HYPERATIVA_TESTE_SR.Data.Map;
using HYPERATIVA_TESTE_SR.Models;
using Microsoft.EntityFrameworkCore;

namespace HYPERATIVA_TESTE_SR.Data
{
    public class HYPERATIVA_TESTE_SR_DBContext : DbContext
    {
        public HYPERATIVA_TESTE_SR_DBContext(DbContextOptions<HYPERATIVA_TESTE_SR_DBContext> options)
            : base(options)
        {
        }

        public DbSet<UsuarioModel> Usuarios { get; set; }
        public DbSet<CartaoModel> Cartao { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new UsuarioMap());
            modelBuilder.ApplyConfiguration(new CartaoMap()); 
            base.OnModelCreating(modelBuilder);
        }

    }
}
